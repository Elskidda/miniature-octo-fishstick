// Main Application Logic for Naija Strategy Games
class NaijaStrategyApp {
    constructor() {
        this.currentUser = {
            id: 'user_123', // Mock user ID
            stars: 100,
            xp: 0,
            vipLevel: 1,
            lastDailyBonus: null
        };
        
        this.gameState = {
            mode: null,
            active: false,
            endTime: null,
            prizePool: 0,
            userVote: null,
            timerInterval: null
        };

        this.init();
    }

    init() {
        // Initialize game logic
        this.gameLogic = new GameLogic(this);
        
        // Load user data from storage
        this.loadUserData();
        
        // Update UI with current user stats
        this.updateUserInterface();
        
        // Set up event listeners
        this.setupEventListeners();
        
        // Check for active games
        this.checkActiveGame();
    }

    loadUserData() {
        const savedUser = BB.stor("users." + this.currentUser.id);
        if (savedUser) {
            this.currentUser = { ...this.currentUser, ...savedUser };
        } else {
            // First time user - save initial data
            this.saveUserData();
        }
    }

    saveUserData() {
        BB.stor("users." + this.currentUser.id, this.currentUser);
    }

    updateUserInterface() {
        // Update header stats with null checks
        const starsElement = document.getElementById('user-stars');
        const xpElement = document.getElementById('user-xp');
        const vipElement = document.getElementById('vip-level');
        
        if (starsElement) starsElement.textContent = this.currentUser.stars;
        if (xpElement) xpElement.textContent = this.currentUser.xp;
        if (vipElement) {
            vipElement.textContent = `VIP ${this.currentUser.vipLevel}`;
            vipElement.className = `vip-badge vip-${this.currentUser.vipLevel}`;
        }
        
        // Update daily bonus button
        this.updateDailyBonusButton();
    }

    updateDailyBonusButton() {
        const bonusBtn = document.getElementById('daily-bonus-text');
        if (!bonusBtn) return;
        
        const lastBonus = this.currentUser.lastDailyBonus;
        const now = Date.now();
        const dayMs = 24 * 60 * 60 * 1000;
        
        if (!lastBonus || (now - lastBonus) >= dayMs) {
            bonusBtn.textContent = 'Claim Daily Bonus';
            bonusBtn.parentElement.classList.remove('disabled');
        } else {
            const nextBonus = lastBonus + dayMs;
            const hoursLeft = Math.ceil((nextBonus - now) / (60 * 60 * 1000));
            bonusBtn.textContent = `Next bonus in ${hoursLeft}h`;
            bonusBtn.parentElement.classList.add('disabled');
        }
    }

    setupEventListeners() {
        // Auto-update timer every second when game is active
        setInterval(() => {
            if (this.gameState.active && this.gameState.endTime) {
                this.updateGameTimer();
            }
            this.updateDailyBonusButton();
        }, 1000);

        // Admin panel key combination (Ctrl+Shift+A)
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.shiftKey && e.key === 'A') {
                e.preventDefault();
                this.showAdminPanel();
            }
        });
    }

    checkActiveGame() {
        const activeGame = BB.stor("game.current");
        if (activeGame && activeGame.endTime > Date.now()) {
            // Resume active game
            this.gameState = activeGame;
            this.showGameScreen();
            this.gameLogic.displayVotingOptions();
        }
    }

    showScreen(screenId) {
        // Hide all screens
        document.querySelectorAll('.screen').forEach(screen => {
            screen.classList.remove('active');
        });
        
        // Show target screen
        document.getElementById(screenId).classList.add('active');
    }

    showGameScreen() {
        this.showScreen('game-screen');
    }

    showResultScreen() {
        this.showScreen('result-screen');
    }

    showVIPScreen() {
        this.updateVIPScreen();
        this.showScreen('vip-screen');
    }

    updateVIPScreen() {
        const currentLevel = this.currentUser.vipLevel;
        const currentXP = this.currentUser.xp;
        const nextLevelXP = this.getXPRequiredForLevel(currentLevel + 1);
        const progress = (currentXP / nextLevelXP) * 100;
        
        document.getElementById('current-vip-level').textContent = `VIP Level ${currentLevel}`;
        document.getElementById('current-xp').textContent = currentXP;
        document.getElementById('next-level-xp').textContent = nextLevelXP;
        document.getElementById('xp-progress-bar').style.width = `${Math.min(progress, 100)}%`;
        
        // Update benefits
        this.updateVIPBenefits();
    }

    updateVIPBenefits() {
        const currentBenefits = this.getVIPBenefits(this.currentUser.vipLevel);
        const nextBenefits = this.getVIPBenefits(this.currentUser.vipLevel + 1);
        
        document.getElementById('current-benefits').innerHTML = 
            currentBenefits.map(benefit => `<li>${benefit}</li>`).join('');
        
        document.getElementById('next-benefits').innerHTML = 
            nextBenefits.map(benefit => `<li>${benefit}</li>`).join('');
    }

    getVIPBenefits(level) {
        const benefits = {
            1: ['✨ Basic game access', '🎁 Daily bonus eligible'],
            2: ['⚡ +20% XP bonus', '💎 Premium game modes', '🎁 Enhanced daily bonus'],
            3: ['🔥 +40% XP bonus', '💰 5% cashback on losses', '⭐ Priority support'],
            4: ['💫 +60% XP bonus', '🏆 Exclusive tournaments', '💎 VIP-only games'],
            5: ['👑 +100% XP bonus', '🌟 Maximum privileges', '💰 10% cashback']
        };
        return benefits[level] || benefits[1];
    }

    getXPRequiredForLevel(level) {
        const baseXP = 100;
        return baseXP * Math.pow(2, level - 1);
    }

    returnToMenu() {
        this.showScreen('main-menu');
        
        // Clean up any active game timers
        if (this.gameState.timerInterval) {
            clearInterval(this.gameState.timerInterval);
            this.gameState.timerInterval = null;
        }
    }

    async claimDailyBonus() {
        const lastBonus = this.currentUser.lastDailyBonus;
        const now = Date.now();
        const dayMs = 24 * 60 * 60 * 1000;
        
        if (lastBonus && (now - lastBonus) < dayMs) {
            this.showToast('Daily bonus already claimed today!', 'warning');
            return;
        }
        
        // Calculate bonus amount based on VIP level and admin settings
        const adminSettings = BB.stor("admin.settings");
        const baseBonus = (adminSettings && adminSettings.dailyBonusAmount) ? adminSettings.dailyBonusAmount : 10;
        const vipMultiplier = 1 + (this.currentUser.vipLevel - 1) * 0.5;
        const bonusAmount = Math.floor(baseBonus * vipMultiplier);
        
        // Award bonus
        this.currentUser.stars += bonusAmount;
        this.currentUser.lastDailyBonus = now;
        this.saveUserData();
        
        // Update UI
        this.updateUserInterface();
        this.showToast(`Daily bonus claimed! +${bonusAmount} Stars`, 'success');
    }

    showComingSoon(mode) {
        const modeNames = {
            minority: 'Elect Minority',
            market: 'Influence Market'
        };
        this.showToast(`${modeNames[mode]} coming soon! 🚀`, 'info');
    }

    addXP(amount) {
        const vipBonus = 1 + (this.currentUser.vipLevel - 1) * 0.2;
        const finalAmount = Math.floor(amount * vipBonus);
        
        this.currentUser.xp += finalAmount;
        
        // Check for level up
        const newLevel = this.calculateVIPLevel(this.currentUser.xp);
        if (newLevel > this.currentUser.vipLevel) {
            this.currentUser.vipLevel = newLevel;
            this.showToast(`🎉 VIP Level Up! You are now VIP ${newLevel}!`, 'success');
        }
        
        this.saveUserData();
        return finalAmount;
    }

    calculateVIPLevel(xp) {
        let level = 1;
        let requiredXP = 100;
        
        while (xp >= requiredXP && level < 5) {
            level++;
            requiredXP = this.getXPRequiredForLevel(level);
        }
        
        return level;
    }

    showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <div class="toast-content">
                <span>${message}</span>
                <button class="toast-close" onclick="this.parentElement.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        document.getElementById('toast-container').appendChild(toast);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (toast.parentElement) {
                toast.remove();
            }
        }, 5000);
    }

    updateGameTimer() {
        if (!this.gameState.endTime) return;
        
        const now = Date.now();
        const timeLeft = this.gameState.endTime - now;
        
        if (timeLeft <= 0) {
            this.endGame();
            return;
        }
        
        const minutes = Math.floor(timeLeft / (60 * 1000));
        const seconds = Math.floor((timeLeft % (60 * 1000)) / 1000);
        
        const timerElement = document.getElementById('countdown-timer');
        if (timerElement) {
            timerElement.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        }
    }

    endGame() {
        if (this.gameState.timerInterval) {
            clearInterval(this.gameState.timerInterval);
            this.gameState.timerInterval = null;
        }
        
        this.gameState.active = false;
        
        // Calculate results based on game mode
        if (this.gameState.mode === 'majority') {
            this.calculateMajorityResults();
        }
        
        // Clear active game from storage
        BB.stor("game.current", null);
    }

    calculateMajorityResults() {
        const votes = BB.stor("game.current.votes") || [];
        const options = BB.stor("game.options") || [];
        
        // Count votes for each option
        const voteCounts = {};
        options.forEach(option => {
            voteCounts[option] = 0;
        });
        
        votes.forEach(vote => {
            if (voteCounts.hasOwnProperty(vote.option)) {
                voteCounts[vote.option]++;
            }
        });
        
        // Add invisible admin vote to random option to ensure house edge
        const randomOption = options[Math.floor(Math.random() * options.length)];
        voteCounts[randomOption]++;
        
        // Find winning option
        const winningOption = Object.keys(voteCounts).reduce((a, b) => 
            voteCounts[a] > voteCounts[b] ? a : b
        );
        
        // Calculate winnings for user
        const userVote = this.gameState.userVote;
        const isWinner = userVote === winningOption;
        const winnersCount = voteCounts[winningOption];
        
        let starsWon = 0;
        if (isWinner && winnersCount > 0) {
            // Split prize pool using admin settings
            const adminSettings = BB.stor("admin.settings");
            const prizePercentage = (adminSettings && adminSettings.poolSplit) ? adminSettings.poolSplit.prize / 100 : 0.7;
            starsWon = Math.floor((this.gameState.prizePool * prizePercentage) / winnersCount);
            this.currentUser.stars += starsWon;
        }
        
        // Award XP
        const baseXP = 5;
        const bonusXP = isWinner ? 10 : 0;
        const xpGained = this.addXP(baseXP + bonusXP);
        
        this.saveUserData();
        
        // Show results
        this.displayGameResults(winningOption, userVote, isWinner, starsWon, xpGained);
    }

    displayGameResults(winningWord, userChoice, isWinner, starsWon, xpGained) {
        const winningWordElement = document.getElementById('winning-word');
        const userChoiceElement = document.getElementById('user-choice');
        const starsWonElement = document.getElementById('stars-won');
        const xpGainedElement = document.getElementById('xp-gained');

        if (winningWordElement) winningWordElement.textContent = winningWord;
        if (userChoiceElement) userChoiceElement.textContent = userChoice;
        if (starsWonElement) starsWonElement.textContent = starsWon;
        if (xpGainedElement) xpGainedElement.textContent = xpGained;
        
        const outcomeDisplay = document.getElementById('outcome-display');
        if (outcomeDisplay) {
            if (isWinner) {
                outcomeDisplay.innerHTML = `
                    <div class="outcome-win">
                        <i class="fas fa-trophy"></i>
                        <h3>🎉 You Won!</h3>
                        <p>Great prediction! You chose the majority favorite.</p>
                    </div>
                `;
            } else {
                outcomeDisplay.innerHTML = `
                    <div class="outcome-lose">
                        <i class="fas fa-handshake"></i>
                        <h3>Better luck next time!</h3>
                        <p>Your choice wasn't the crowd favorite, but you still earned XP!</p>
                    </div>
                `;
            }
        }
        
        // Update UI with new stats
        this.updateUserInterface();
        
        // Show result screen
        this.showResultScreen();
    }

    showAdminPanel() {
        const adminSettings = BB.stor("admin.settings") || {
            gameDuration: 180000, // 3 minutes in milliseconds
            entryFees: { majority: 3, minority: 4, market: 5 },
            revoteCost: 2,
            poolSplit: { admin: 20, xp: 10, prize: 70 },
            maxPlayers: 100,
            minPlayers: 2,
            simulatedPlayers: true,
            dailyBonusAmount: 10,
            xpRequiredForLevels: [100, 200, 400, 800, 1600]
        };

        const adminModal = document.createElement('div');
        adminModal.className = 'modal-overlay admin-panel';
        adminModal.innerHTML = `
            <div class="modal-content admin-content">
                <div class="modal-header">
                    <h3>🔧 Admin Panel</h3>
                    <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body admin-body">
                    <div class="admin-section">
                        <h4>Game Settings</h4>
                        <div class="admin-row">
                            <label>Game Duration (seconds):</label>
                            <input type="number" id="admin-duration" value="${adminSettings.gameDuration / 1000}" min="30" max="600">
                        </div>
                        <div class="admin-row">
                            <label>Majority Entry Fee:</label>
                            <input type="number" id="admin-majority-fee" value="${adminSettings.entryFees.majority}" min="1" max="50">
                        </div>
                        <div class="admin-row">
                            <label>Minority Entry Fee:</label>
                            <input type="number" id="admin-minority-fee" value="${adminSettings.entryFees.minority}" min="1" max="50">
                        </div>
                        <div class="admin-row">
                            <label>Market Entry Fee:</label>
                            <input type="number" id="admin-market-fee" value="${adminSettings.entryFees.market}" min="1" max="50">
                        </div>
                        <div class="admin-row">
                            <label>Revote Cost:</label>
                            <input type="number" id="admin-revote-cost" value="${adminSettings.revoteCost}" min="1" max="20">
                        </div>
                    </div>

                    <div class="admin-section">
                        <h4>Economy Settings</h4>
                        <div class="admin-row">
                            <label>Admin Cut (%):</label>
                            <input type="number" id="admin-cut" value="${adminSettings.poolSplit.admin}" min="0" max="50">
                        </div>
                        <div class="admin-row">
                            <label>XP Pool (%):</label>
                            <input type="number" id="admin-xp-pool" value="${adminSettings.poolSplit.xp}" min="0" max="30">
                        </div>
                        <div class="admin-row">
                            <label>Prize Pool (%):</label>
                            <input type="number" id="admin-prize-pool" value="${adminSettings.poolSplit.prize}" min="50" max="100">
                        </div>
                        <div class="admin-row">
                            <label>Daily Bonus Amount:</label>
                            <input type="number" id="admin-daily-bonus" value="${adminSettings.dailyBonusAmount}" min="5" max="100">
                        </div>
                    </div>

                    <div class="admin-section">
                        <h4>Player Settings</h4>
                        <div class="admin-row">
                            <label>Max Players:</label>
                            <input type="number" id="admin-max-players" value="${adminSettings.maxPlayers}" min="10" max="1000">
                        </div>
                        <div class="admin-row">
                            <label>Min Players:</label>
                            <input type="number" id="admin-min-players" value="${adminSettings.minPlayers}" min="1" max="20">
                        </div>
                        <div class="admin-row">
                            <label>
                                <input type="checkbox" id="admin-simulated-players" ${adminSettings.simulatedPlayers ? 'checked' : ''}>
                                Enable Simulated Players
                            </label>
                        </div>
                    </div>

                    <div class="admin-section">
                        <h4>Quick Actions</h4>
                        <div class="admin-actions">
                            <button class="bb-button warning small" onclick="app.adminAddStars()">Add 100 Stars</button>
                            <button class="bb-button info small" onclick="app.adminAddXP()">Add 500 XP</button>
                            <button class="bb-button danger small" onclick="app.adminResetUser()">Reset User Data</button>
                            <button class="bb-button secondary small" onclick="app.adminEndGame()">Force End Game</button>
                        </div>
                    </div>

                    <div class="admin-section">
                        <h4>Current Game Status</h4>
                        <div class="admin-info">
                            <p><strong>Active Game:</strong> ${this.gameState.active ? this.gameState.mode : 'None'}</p>
                            <p><strong>Prize Pool:</strong> ${this.gameState.prizePool} Stars</p>
                            <p><strong>Players Voted:</strong> ${(BB.stor("game.current.votes") || []).length}</p>
                            <p><strong>Time Left:</strong> ${this.gameState.endTime ? Math.max(0, Math.ceil((this.gameState.endTime - Date.now()) / 1000)) : 0}s</p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="bb-button secondary" onclick="this.closest('.modal-overlay').remove()">Cancel</button>
                    <button class="bb-button primary" onclick="app.saveAdminSettings()">Save Settings</button>
                </div>
            </div>
        `;

        document.body.appendChild(adminModal);
    }

    saveAdminSettings() {
        const settings = {
            gameDuration: parseInt(document.getElementById('admin-duration').value) * 1000,
            entryFees: {
                majority: parseInt(document.getElementById('admin-majority-fee').value),
                minority: parseInt(document.getElementById('admin-minority-fee').value),
                market: parseInt(document.getElementById('admin-market-fee').value)
            },
            revoteCost: parseInt(document.getElementById('admin-revote-cost').value),
            poolSplit: {
                admin: parseInt(document.getElementById('admin-cut').value),
                xp: parseInt(document.getElementById('admin-xp-pool').value),
                prize: parseInt(document.getElementById('admin-prize-pool').value)
            },
            maxPlayers: parseInt(document.getElementById('admin-max-players').value),
            minPlayers: parseInt(document.getElementById('admin-min-players').value),
            simulatedPlayers: document.getElementById('admin-simulated-players').checked,
            dailyBonusAmount: parseInt(document.getElementById('admin-daily-bonus').value)
        };

        BB.stor("admin.settings", settings);
        this.showToast('Admin settings saved successfully!', 'success');
        document.querySelector('.admin-panel').remove();
    }

    adminAddStars() {
        this.currentUser.stars += 100;
        this.saveUserData();
        this.updateUserInterface();
        this.showToast('Added 100 Stars!', 'success');
    }

    adminAddXP() {
        this.addXP(500);
        this.updateUserInterface();
        this.showToast('Added 500 XP!', 'success');
    }

    adminResetUser() {
        if (confirm('Are you sure you want to reset all user data?')) {
            this.currentUser = {
                id: 'user_123',
                stars: 100,
                xp: 0,
                vipLevel: 1,
                lastDailyBonus: null
            };
            this.saveUserData();
            this.updateUserInterface();
            this.showToast('User data reset!', 'warning');
        }
    }

    adminEndGame() {
        if (this.gameState.active) {
            this.endGame();
            this.showToast('Game force ended!', 'warning');
        } else {
            this.showToast('No active game to end!', 'info');
        }
    }
}

// Global functions for HTML onclick handlers
function startGame(mode) {
    app.gameLogic.startGame(mode);
}

function vote(option) {
    app.gameLogic.vote(option);
}

function confirmRevote() {
    app.gameLogic.confirmRevote();
}

function returnToMenu() {
    app.returnToMenu();
}

function claimDailyBonus() {
    app.claimDailyBonus();
}

function showVIPScreen() {
    app.showVIPScreen();
}

function showComingSoon(mode) {
    app.showComingSoon(mode);
}

// Initialize app when DOM is loaded
let app;
document.addEventListener('DOMContentLoaded', () => {
    app = new NaijaStrategyApp();
});
