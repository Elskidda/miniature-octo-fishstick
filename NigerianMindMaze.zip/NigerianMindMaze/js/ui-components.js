// UI Components and Utilities for Naija Strategy Games

class UIComponents {
    constructor() {
        this.toastQueue = [];
        this.activeToasts = [];
    }

    // Create a loading overlay
    showLoading(message = 'Loading...') {
        const overlay = document.getElementById('loading-overlay');
        const loadingText = overlay.querySelector('p');
        loadingText.textContent = message;
        overlay.style.display = 'flex';
    }

    hideLoading() {
        document.getElementById('loading-overlay').style.display = 'none';
    }

    // Create modal dialog
    showModal(title, content, buttons = []) {
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>${title}</h3>
                    <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    ${content}
                </div>
                <div class="modal-footer">
                    ${buttons.map(btn => `
                        <div class="bb-button ${btn.class || 'secondary'}" onclick="${btn.onclick}">
                            ${btn.text}
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        return modal;
    }

    // Confirmation dialog
    showConfirmation(message, onConfirm, onCancel = null) {
        const buttons = [
            {
                text: 'Cancel',
                class: 'secondary',
                onclick: `this.closest('.modal-overlay').remove(); ${onCancel || ''}`
            },
            {
                text: 'Confirm',
                class: 'primary',
                onclick: `this.closest('.modal-overlay').remove(); ${onConfirm}`
            }
        ];

        return this.showModal('Confirmation', `<p>${message}</p>`, buttons);
    }

    // Animate number changes
    animateNumber(element, startValue, endValue, duration = 1000) {
        const start = performance.now();
        const change = endValue - startValue;

        const animate = (currentTime) => {
            const elapsed = currentTime - start;
            const progress = Math.min(elapsed / duration, 1);
            
            // Easing function (ease-out)
            const easeOut = 1 - Math.pow(1 - progress, 3);
            const currentValue = Math.floor(startValue + (change * easeOut));
            
            element.textContent = currentValue;
            
            if (progress < 1) {
                requestAnimationFrame(animate);
            }
        };

        requestAnimationFrame(animate);
    }

    // Pulse animation for elements
    pulseElement(element, duration = 600) {
        element.style.animation = `pulse ${duration}ms ease-in-out`;
        setTimeout(() => {
            element.style.animation = '';
        }, duration);
    }

    // Shake animation for errors
    shakeElement(element, duration = 500) {
        element.style.animation = `shake ${duration}ms ease-in-out`;
        setTimeout(() => {
            element.style.animation = '';
        }, duration);
    }

    // Create progress bar
    createProgressBar(percentage, className = '') {
        return `
            <div class="progress-bar ${className}">
                <div class="progress-fill" style="width: ${percentage}%"></div>
            </div>
        `;
    }

    // Format numbers with Nigerian formatting
    formatNumber(number) {
        return new Intl.NumberFormat('en-NG').format(number);
    }

    // Format currency (Stars)
    formatStars(amount) {
        return `${this.formatNumber(amount)} Stars`;
    }

    // Create countdown display
    formatTime(milliseconds) {
        const totalSeconds = Math.floor(milliseconds / 1000);
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = totalSeconds % 60;
        return `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }

    // Create badge element
    createBadge(text, type = 'default') {
        return `<span class="badge badge-${type}">${text}</span>`;
    }

    // Create icon with text
    createIconText(icon, text, className = '') {
        return `
            <span class="icon-text ${className}">
                <i class="${icon}"></i>
                <span>${text}</span>
            </span>
        `;
    }

    // Smooth scroll to element
    scrollToElement(elementId, offset = 0) {
        const element = document.getElementById(elementId);
        if (element) {
            const elementPosition = element.offsetTop - offset;
            window.scrollTo({
                top: elementPosition,
                behavior: 'smooth'
            });
        }
    }

    // Copy text to clipboard
    async copyToClipboard(text) {
        try {
            await navigator.clipboard.writeText(text);
            return true;
        } catch (err) {
            // Fallback for older browsers
            const textArea = document.createElement('textarea');
            textArea.value = text;
            document.body.appendChild(textArea);
            textArea.select();
            try {
                document.execCommand('copy');
                return true;
            } catch (err) {
                return false;
            } finally {
                document.body.removeChild(textArea);
            }
        }
    }

    // Debounce function for performance
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Throttle function for performance
    throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }

    // Generate random Nigerian-themed messages
    getRandomNaijaMessage(type) {
        const messages = {
            encouragement: [
                "Na you sabi pass! 💪",
                "You go win this one! 🏆",
                "Make we try again! 🚀",
                "Na small thing! 😎",
                "You get this! 💯"
            ],
            celebration: [
                "Chai! You don win! 🎉",
                "Na your time be this! ⭐",
                "You too much! 🔥",
                "Correct guy! 👑",
                "Na you be the boss! 🏆"
            ],
            sympathy: [
                "No wahala, try again! 💪",
                "Next time na your time! ⏰",
                "E go better! 🌟",
                "Make we try again! 🔄",
                "No give up! 💯"
            ]
        };

        const typeMessages = messages[type] || messages.encouragement;
        return typeMessages[Math.floor(Math.random() * typeMessages.length)];
    }
}

// Global UI utilities
window.UI = new UIComponents();

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
    }

    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
        20%, 40%, 60%, 80% { transform: translateX(5px); }
    }

    @keyframes slideIn {
        from { transform: translateY(-100%); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
    }

    @keyframes slideOut {
        from { transform: translateY(0); opacity: 1; }
        to { transform: translateY(-100%); opacity: 0; }
    }

    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    @keyframes bounceIn {
        0% { transform: scale(0.3); opacity: 0; }
        50% { transform: scale(1.1); }
        70% { transform: scale(0.9); }
        100% { transform: scale(1); opacity: 1; }
    }
`;
document.head.appendChild(style);
