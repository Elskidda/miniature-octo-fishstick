// Mock Bots.Business Storage System
// This simulates the BB.stor functionality for development

class BBStorage {
    constructor() {
        this.storage = {};
        this.loadFromLocalStorage();
    }

    // Get or set storage value
    stor(key, value = undefined) {
        if (value === undefined) {
            // Get value
            return this.getValue(key);
        } else {
            // Set value
            this.setValue(key, value);
            this.saveToLocalStorage();
            return value;
        }
    }

    getValue(key) {
        const keys = key.split('.');
        let current = this.storage;
        
        for (const k of keys) {
            if (current && typeof current === 'object' && k in current) {
                current = current[k];
            } else {
                return undefined;
            }
        }
        
        return current;
    }

    setValue(key, value) {
        const keys = key.split('.');
        let current = this.storage;
        
        for (let i = 0; i < keys.length - 1; i++) {
            const k = keys[i];
            if (!(k in current) || typeof current[k] !== 'object') {
                current[k] = {};
            }
            current = current[k];
        }
        
        const lastKey = keys[keys.length - 1];
        if (value === null || value === undefined) {
            delete current[lastKey];
        } else {
            current[lastKey] = value;
        }
    }

    loadFromLocalStorage() {
        try {
            const stored = localStorage.getItem('naija-strategy-games');
            if (stored) {
                this.storage = JSON.parse(stored);
            }
        } catch (error) {
            console.warn('Failed to load from localStorage:', error);
            this.storage = {};
        }
    }

    saveToLocalStorage() {
        try {
            localStorage.setItem('naija-strategy-games', JSON.stringify(this.storage));
        } catch (error) {
            console.warn('Failed to save to localStorage:', error);
        }
    }

    // Debug method to view all storage
    debug() {
        console.log('BB Storage Contents:', this.storage);
        return this.storage;
    }
}

// Global BB object to simulate Bots.Business environment
window.BB = new BBStorage();

// Initialize with some default data if empty
if (!BB.stor("game.options")) {
    // Nigerian-themed word options for voting
    const gameOptions = [
        "Naija", "Lagos", "Jollof", "Afrobeat", "Lagos", 
        "Eko", "Wahala", "Sabi", "Gidi", "Buka"
    ];
    BB.stor("game.options", gameOptions);
}

// Set up some initial game state if needed
if (!BB.stor("game.current")) {
    BB.stor("game.current", {
        mode: null,
        active: false,
        endTime: null,
        prizePool: 0,
        votes: []
    });
}
