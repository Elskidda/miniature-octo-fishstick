// Game Logic for Naija Strategy Games

class GameLogic {
    constructor(app) {
        this.app = app;
        this.gameOptions = [
            "Naija", "Lagos", "Jollof", "Afrobeat", "Buka",
            "Eko", "Wahala", "Sabi", "Gidi", "Danfo"
        ];
    }

    async startGame(mode) {
        // Check if user has enough stars
        const entryFee = this.getEntryFee(mode);
        if (this.app.currentUser.stars < entryFee) {
            this.app.showToast(`You need ${entryFee} Stars to play this game!`, 'warning');
            return;
        }

        // Check if there's already an active game
        const activeGame = BB.stor("game.current");
        if (activeGame && activeGame.active && activeGame.endTime > Date.now()) {
            this.app.showToast('A game is already in progress!', 'warning');
            return;
        }

        // Deduct entry fee
        this.app.currentUser.stars -= entryFee;
        this.app.saveUserData();

        // Set up new game
        const adminSettings = BB.stor("admin.settings");
        const gameDuration = (adminSettings && adminSettings.gameDuration) ? adminSettings.gameDuration : 180000; // Default 3 minutes
        const endTime = Date.now() + gameDuration;
        this.app.gameState = {
            mode: mode,
            active: true,
            endTime: endTime,
            prizePool: entryFee,
            userVote: null,
            timerInterval: null
        };

        // Initialize game storage
        BB.stor("game.current", this.app.gameState);
        BB.stor("game.current.votes", []);
        BB.stor("game.options", this.gameOptions);

        // Update prize pool with existing contributions
        const existingPool = BB.stor("game.current.prizePool") || 0;
        this.app.gameState.prizePool = existingPool + entryFee;
        BB.stor("game.current.prizePool", this.app.gameState.prizePool);

        // Show game screen
        this.setupGameScreen(mode);
        this.app.showGameScreen();
        this.displayVotingOptions();

        // Add simulated players after a short delay
        setTimeout(() => {
            this.simulateOtherPlayers();
        }, 2000);

        // Update UI
        this.app.updateUserInterface();
        this.app.showToast(`Game started! Entry fee: ${entryFee} Stars`, 'success');
    }

    getEntryFee(mode) {
        const adminSettings = BB.stor("admin.settings");
        if (adminSettings && adminSettings.entryFees) {
            return adminSettings.entryFees[mode] || 3;
        }
        const fees = {
            majority: 3,
            minority: 4,
            market: 5
        };
        return fees[mode] || 3;
    }

    setupGameScreen(mode) {
        const titles = {
            majority: '🟩 Elect Majority',
            minority: '🟦 Elect Minority',
            market: '🟥 Influence Market'
        };

        const instructions = {
            majority: 'Vote for the word you think will get the most votes!',
            minority: 'Vote for the word you think will get the least votes!',
            market: 'Be in the minority at the final second!'
        };

        const titleElement = document.getElementById('game-mode-title');
        const instructionsElement = document.getElementById('game-instructions');
        const prizePoolElement = document.getElementById('prize-pool');
        const revoteBtnElement = document.getElementById('revote-btn');

        if (titleElement) titleElement.textContent = titles[mode];
        if (instructionsElement) instructionsElement.textContent = instructions[mode];
        if (prizePoolElement) prizePoolElement.textContent = this.app.gameState.prizePool;
        if (revoteBtnElement) revoteBtnElement.style.display = 'none';
    }

    displayVotingOptions() {
        const optionsContainer = document.getElementById('voting-options');
        if (!optionsContainer) return;
        
        optionsContainer.innerHTML = '';

        this.gameOptions.forEach((option, index) => {
            const optionElement = document.createElement('div');
            optionElement.className = 'voting-option';
            optionElement.innerHTML = `
                <div class="bb-button vote-option" onclick="vote('${option}')">
                    <div class="option-content">
                        <div class="option-emoji">${this.getOptionEmoji(option)}</div>
                        <div class="option-text">${option}</div>
                        <div class="option-votes" id="votes-${option}" style="display: none;">
                            0 votes
                        </div>
                    </div>
                </div>
            `;
            optionsContainer.appendChild(optionElement);
        });
    }

    getOptionEmoji(option) {
        const emojis = {
            "Naija": "🇳🇬",
            "Lagos": "🏙️",
            "Jollof": "🍚",
            "Afrobeat": "🎵",
            "Buka": "🍽️",
            "Eko": "🌊",
            "Wahala": "😅",
            "Sabi": "🧠",
            "Gidi": "✨",
            "Danfo": "🚐"
        };
        return emojis[option] || "⭐";
    }

    vote(option) {
        if (!this.app.gameState.active) {
            this.app.showToast('No active game!', 'warning');
            return;
        }

        if (this.app.gameState.endTime <= Date.now()) {
            this.app.showToast('Voting time has ended!', 'warning');
            return;
        }

        // Record the vote
        this.app.gameState.userVote = option;
        
        // Update storage
        const votes = BB.stor("game.current.votes") || [];
        const existingVoteIndex = votes.findIndex(v => v.user_id === this.app.currentUser.id);
        
        if (existingVoteIndex >= 0) {
            // User already voted, update their vote
            votes[existingVoteIndex].option = option;
        } else {
            // New vote
            votes.push({
                user_id: this.app.currentUser.id,
                option: option,
                timestamp: Date.now()
            });
        }
        
        BB.stor("game.current.votes", votes);

        // Update UI
        this.highlightSelectedOption(option);
        this.showRevoteButton();
        
        this.app.showToast(`You voted for: ${option}`, 'success');
    }

    highlightSelectedOption(selectedOption) {
        // Remove previous selection
        document.querySelectorAll('.vote-option').forEach(btn => {
            btn.classList.remove('selected');
        });

        // Highlight selected option
        document.querySelectorAll('.vote-option').forEach(btn => {
            const optionText = btn.querySelector('.option-text').textContent;
            if (optionText === selectedOption) {
                btn.classList.add('selected');
            }
        });
    }

    showRevoteButton() {
        const adminSettings = BB.stor("admin.settings");
        const revoteCost = (adminSettings && adminSettings.revoteCost) ? adminSettings.revoteCost : 2;
        const revoteTextElement = document.getElementById('revote-text');
        if (revoteTextElement) {
            revoteTextElement.textContent = `Revote (${revoteCost} Stars)`;
        }
        const revoteBtnElement = document.getElementById('revote-btn');
        if (revoteBtnElement) {
            revoteBtnElement.style.display = 'block';
        }
    }

    confirmRevote() {
        const adminSettings = BB.stor("admin.settings");
        const revoteCost = (adminSettings && adminSettings.revoteCost) ? adminSettings.revoteCost : 2;
        
        if (this.app.currentUser.stars < revoteCost) {
            this.app.showToast(`You need ${revoteCost} Stars to revote!`, 'warning');
            return;
        }

        // Confirm with user
        const confirmed = confirm(`Revote costs ${revoteCost} Stars. Continue?`);
        if (!confirmed) return;

        // Deduct revote cost
        this.app.currentUser.stars -= revoteCost;
        this.app.saveUserData();

        // Add to prize pool using admin settings
        const poolPercentage = (adminSettings && adminSettings.poolSplit) ? adminSettings.poolSplit.prize / 100 : 0.7;
        const poolAddition = Math.floor(revoteCost * poolPercentage);
        this.app.gameState.prizePool += poolAddition;
        BB.stor("game.current.prizePool", this.app.gameState.prizePool);

        // Update prize pool display
        const prizePoolElement = document.getElementById('prize-pool');
        if (prizePoolElement) {
            prizePoolElement.textContent = this.app.gameState.prizePool;
        }

        // Reset vote selection
        this.app.gameState.userVote = null;
        document.querySelectorAll('.vote-option').forEach(btn => {
            btn.classList.remove('selected');
        });

        // Hide revote button
        const revoteBtnElement = document.getElementById('revote-btn');
        if (revoteBtnElement) {
            revoteBtnElement.style.display = 'none';
        }

        // Update UI
        this.app.updateUserInterface();
        this.app.showToast(`Revote enabled! Choose your new option.`, 'info');
    }

    // Method to simulate other players joining (for demo purposes)
    simulateOtherPlayers() {
        if (!this.app.gameState.active) return;

        const votes = BB.stor("game.current.votes") || [];
        const playerCount = Math.floor(Math.random() * 20) + 5; // 5-25 simulated players

        // Add some simulated votes if enabled
        const adminSettings = BB.stor("admin.settings");
        if (!adminSettings || adminSettings.simulatedPlayers !== false) {
            for (let i = 0; i < playerCount; i++) {
                const randomOption = this.gameOptions[Math.floor(Math.random() * this.gameOptions.length)];
                const simulatedUserId = `sim_user_${i}`;
                
                // Check if this simulated user already voted
                const existingVote = votes.find(v => v.user_id === simulatedUserId);
                if (!existingVote) {
                    votes.push({
                        user_id: simulatedUserId,
                        option: randomOption,
                        timestamp: Date.now() + Math.random() * 1000
                    });
                }
            }
        }

        BB.stor("game.current.votes", votes);

        // Update prize pool using admin settings
        const entryFee = this.getEntryFee('majority'); // Get current entry fee
        const poolPercentage = (adminSettings && adminSettings.poolSplit) ? adminSettings.poolSplit.prize / 100 : 0.7;
        const additionalPool = playerCount * entryFee * poolPercentage;
        this.app.gameState.prizePool += additionalPool;
        BB.stor("game.current.prizePool", this.app.gameState.prizePool);
        const prizePoolElement = document.getElementById('prize-pool');
        if (prizePoolElement) {
            prizePoolElement.textContent = Math.floor(this.app.gameState.prizePool);
        }
    }
}
